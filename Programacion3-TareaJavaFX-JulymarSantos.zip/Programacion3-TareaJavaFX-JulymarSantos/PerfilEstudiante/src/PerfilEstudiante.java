import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class PerfilEstudiante extends Application {

    @Override
    public void start(Stage primaryStage) {

        BorderPane root = new BorderPane();

        // ===================== TITULO =====================

        Label titulo = new Label("PERFIL DE ESTUDIANTE");
        titulo.setStyle("-fx-font-size:22px; -fx-font-weight:bold;");

        HBox encabezado = new HBox(titulo);
        encabezado.setAlignment(Pos.CENTER);
        encabezado.setPadding(new Insets(15));

        root.setTop(encabezado);

        // ===================== FORMULARIO =====================

        GridPane formulario = new GridPane();
        formulario.setPadding(new Insets(20));
        formulario.setHgap(10);
        formulario.setVgap(10);

        root.setCenter(formulario);

        // ===================== FOTO =====================

        Rectangle foto = new Rectangle(120,150);
        foto.setFill(Color.LIGHTGRAY);
        foto.setStroke(Color.BLACK);

        formulario.add(foto,0,0,1,5);

        // ===================== CAMPOS =====================

        Label lblMatricula = new Label("Matricula:");
        TextField txtMatricula = new TextField();

        Label lblNombre = new Label("Nombre:");
        TextField txtNombre = new TextField();

        Label lblCarrera = new Label("Carrera:");
        TextField txtCarrera = new TextField();

        Label lblCorreo = new Label("Correo:");
        TextField txtCorreo = new TextField();

        Label lblTelefono = new Label("Telefono:");
        TextField txtTelefono = new TextField();

        Label lblDireccion = new Label("Direccion:");
        TextField txtDireccion = new TextField();

        txtMatricula.setPrefWidth(250);
        txtNombre.setPrefWidth(250);
        txtCarrera.setPrefWidth(250);
        txtCorreo.setPrefWidth(250);
        txtTelefono.setPrefWidth(250);
        txtDireccion.setPrefWidth(250);

        formulario.add(lblMatricula,1,0);
        formulario.add(txtMatricula,2,0);

        formulario.add(lblNombre,1,1);
        formulario.add(txtNombre,2,1);

        formulario.add(lblCarrera,1,2);
        formulario.add(txtCarrera,2,2);

        formulario.add(lblCorreo,1,3);
        formulario.add(txtCorreo,2,3);

        formulario.add(lblTelefono,1,4);
        formulario.add(txtTelefono,2,4);

        formulario.add(lblDireccion,1,5);
        formulario.add(txtDireccion,2,5);

        // ===================== COMBOBOX =====================

        ComboBox<String> semestre = new ComboBox<>();

        semestre.getItems().addAll(
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8"
        );

        semestre.setPromptText("Seleccione");
        semestre.setPrefWidth(250);

        formulario.add(new Label("Semestre:"),1,6);
        formulario.add(semestre,2,6);

        // ===================== LISTVIEW =====================

        ListView<String> materias = new ListView<>();

        materias.getItems().addAll(
                "Programacion",
                "Base de Datos",
                "Redes",
                "Ingenieria de Software"
        );

        materias.setPrefHeight(120);

        formulario.add(new Label("Materias:"),1,7);
        formulario.add(materias,2,7);

        // ===================== TEXTAREA =====================

        TextArea observaciones = new TextArea();
        observaciones.setPrefRowCount(4);

        formulario.add(new Label("Observaciones:"),1,8);
        formulario.add(observaciones,2,8);

        // ===================== BOTONES =====================

        Button btnGuardar = new Button("Guardar");
        Button btnActualizar = new Button("Actualizar");
        Button btnImprimir = new Button("Imprimir");

        btnGuardar.setPrefWidth(100);
        btnActualizar.setPrefWidth(100);
        btnImprimir.setPrefWidth(100);

        HBox botones = new HBox(10);

        botones.getChildren().addAll(
                btnGuardar,
                btnActualizar,
                btnImprimir
        );

        formulario.add(botones,2,9);

        // ===================== ESTILO =====================

        root.setStyle("-fx-background-color:#F5F5F5;");

        // ===================== ESCENA =====================

        Scene scene = new Scene(root,900,650);

        primaryStage.setTitle("Perfil de Estudiante");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}