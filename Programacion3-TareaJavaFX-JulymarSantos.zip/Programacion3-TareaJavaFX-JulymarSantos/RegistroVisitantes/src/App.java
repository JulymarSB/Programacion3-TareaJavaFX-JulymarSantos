import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Insets;

public class App extends Application{

    @Override
public void start(Stage primaryStage) {

    BorderPane root = new BorderPane();

    // ===================== TÍTULO =====================

    Label titulo = new Label("REGISTRO DE VISITANTES");
    titulo.setStyle("-fx-font-size:22px; -fx-font-weight:bold;");

    HBox encabezado = new HBox(titulo);
    encabezado.setAlignment(Pos.CENTER);
    encabezado.setPadding(new Insets(15));

    root.setTop(encabezado);

    // ===================== FORMULARIO =====================

    GridPane formulario = new GridPane();
    formulario.setPadding(new Insets(20));
    formulario.setHgap(10);
    formulario.setVgap(10);

    root.setCenter(formulario);

    Label lblNombre = new Label("Nombre:");
    TextField txtNombre = new TextField();
    txtNombre.setPrefWidth(250);

    Label lblCedula = new Label("Cedula:");
    TextField txtCedula = new TextField();
    txtCedula.setPrefWidth(250);

    Label lblTelefono = new Label("Telefono:");
    TextField txtTelefono = new TextField();
    txtTelefono.setPrefWidth(250);

    Label lblMotivo = new Label("Motivo de visita:");
    TextField txtMotivo = new TextField();
    txtMotivo.setPrefWidth(250);

    Label lblPersona = new Label("Persona a visitar:");
    TextField txtPersona = new TextField();
    txtPersona.setPrefWidth(250);

    Label lblFecha = new Label("Fecha:");
    TextField txtFecha = new TextField();
    txtFecha.setPrefWidth(250);

    formulario.add(lblNombre,0,0);
    formulario.add(txtNombre,1,0);

    formulario.add(lblCedula,0,1);
    formulario.add(txtCedula,1,1);

    formulario.add(lblTelefono,0,2);
    formulario.add(txtTelefono,1,2);

    formulario.add(lblMotivo,0,3);
    formulario.add(txtMotivo,1,3);

    formulario.add(lblPersona,0,4);
    formulario.add(txtPersona,1,4);

    formulario.add(lblFecha,0,5);
    formulario.add(txtFecha,1,5);

    // ===================== COMBOBOX =====================

    ComboBox<String> tipoV = new ComboBox<>();

    tipoV.getItems().addAll(
            "Estudiante",
            "Padre/Madre",
            "Suplidor",
            "Invitado"
    );

    tipoV.setPromptText("Seleccione una opcion");
    tipoV.setPrefWidth(250);

    formulario.add(new Label("Tipo de visitante:"),0,6);
    formulario.add(tipoV,1,6);

    // ===================== RADIOBUTTON =====================

    RadioButton rbCedula = new RadioButton("Cedula");
    RadioButton rbPasaporte = new RadioButton("Pasaporte");
    RadioButton rbCarnet = new RadioButton("Carnet");

    ToggleGroup grupoDocumento = new ToggleGroup();

    rbCedula.setToggleGroup(grupoDocumento);
    rbPasaporte.setToggleGroup(grupoDocumento);
    rbCarnet.setToggleGroup(grupoDocumento);

    VBox documentos = new VBox(5);

    documentos.getChildren().addAll(
            rbCedula,
            rbPasaporte,
            rbCarnet
    );

    formulario.add(new Label("Documento:"),0,7);
    formulario.add(documentos,1,7);

    // ===================== BOTONES =====================

    Button btnRegistrar = new Button("Registrar");
    Button btnLimpiar = new Button("Limpiar");
    Button btnCancelar = new Button("Cancelar");

    btnRegistrar.setPrefWidth(100);
    btnLimpiar.setPrefWidth(100);
    btnCancelar.setPrefWidth(100);

    HBox botones = new HBox(10);

    botones.getChildren().addAll(
            btnRegistrar,
            btnLimpiar,
            btnCancelar
    );

    formulario.add(botones,1,8);

    // ===================== TABLA =====================

    TableView<String> tabla = new TableView<>();

    TableColumn<String,String> colNombre =
            new TableColumn<>("Nombre");

    TableColumn<String,String> colCedula =
            new TableColumn<>("Cedula");

    TableColumn<String,String> colTelefono =
            new TableColumn<>("Telefono");

    TableColumn<String,String> colTipo =
            new TableColumn<>("Tipo");

    TableColumn<String,String> colFecha =
            new TableColumn<>("Fecha");

    colNombre.setPrefWidth(170);
    colCedula.setPrefWidth(130);
    colTelefono.setPrefWidth(130);
    colTipo.setPrefWidth(150);
    colFecha.setPrefWidth(120);

    tabla.getColumns().addAll(
            colNombre,
            colCedula,
            colTelefono,
            colTipo,
            colFecha
    );

    tabla.setPrefHeight(220);

    VBox parteInferior = new VBox(tabla);
    parteInferior.setPadding(new Insets(20));

    root.setBottom(parteInferior);

    // ===================== ESTILO =====================

    root.setStyle("-fx-background-color:#ADD8E6;");

    // ===================== ESCENA =====================

    Scene scene = new Scene(root,900,650);

    primaryStage.setTitle("Registro de Visitantes");
    primaryStage.setScene(scene);
    primaryStage.show();
}
    public static void main(String[] args) throws Exception {
        launch(args);
    }
}
