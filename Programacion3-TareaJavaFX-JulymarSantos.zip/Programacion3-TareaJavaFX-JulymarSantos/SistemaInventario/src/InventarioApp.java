import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class InventarioApp extends Application {

    @Override
    public void start(Stage primaryStage) {

        BorderPane root = new BorderPane();

        // ===== TITULO =====
        Label titulo = new Label("SISTEMA DE INVENTARIO");
        titulo.setStyle("-fx-font-size:22px; -fx-font-weight:bold;");

        HBox encabezado = new HBox(titulo);
        encabezado.setAlignment(Pos.CENTER);
        encabezado.setPadding(new Insets(15));

        root.setTop(encabezado);

        // ===== FORMULARIO =====
        GridPane formulario = new GridPane();
        formulario.setPadding(new Insets(20));
        formulario.setHgap(10);
        formulario.setVgap(10);

        root.setCenter(formulario);

        Label lblCodigo = new Label("Codigo:");
        TextField txtCodigo = new TextField();

        Label lblProducto = new Label("Producto:");
        TextField txtProducto = new TextField();

        Label lblCategoria = new Label("Categoria:");
        TextField txtCategoria = new TextField();

        Label lblPrecio = new Label("Precio:");
        TextField txtPrecio = new TextField();

        Label lblCantidad = new Label("Cantidad:");
        TextField txtCantidad = new TextField();

        Label lblProveedor = new Label("Proveedor:");
        TextField txtProveedor = new TextField();

        formulario.add(lblCodigo,0,0);
        formulario.add(txtCodigo,1,0);

        formulario.add(lblProducto,0,1);
        formulario.add(txtProducto,1,1);

        formulario.add(lblCategoria,0,2);
        formulario.add(txtCategoria,1,2);

        formulario.add(lblPrecio,0,3);
        formulario.add(txtPrecio,1,3);

        formulario.add(lblCantidad,0,4);
        formulario.add(txtCantidad,1,4);

        formulario.add(lblProveedor,0,5);
        formulario.add(txtProveedor,1,5);

        // ===== COMBOBOX =====

        ComboBox<String> estado = new ComboBox<>();

        estado.getItems().addAll(
                "Disponible",
                "Agotado",
                "Bajo inventario"
        );

        estado.setPromptText("Seleccione un estado");

        formulario.add(new Label("Estado:"),0,6);
        formulario.add(estado,1,6);

        // ===== CHECKBOX =====

        CheckBox chkPerecedero =
                new CheckBox("Producto perecedero");

        CheckBox chkRefrigeracion =
                new CheckBox("Requiere refrigeracion");

        CheckBox chkImportado =
                new CheckBox("Producto importado");

        VBox opciones = new VBox(5);

        opciones.getChildren().addAll(
                chkPerecedero,
                chkRefrigeracion,
                chkImportado
        );

        formulario.add(new Label("Caracteristicas:"),0,7);
        formulario.add(opciones,1,7);

        // ===== BOTONES =====

        Button btnGuardar = new Button("Guardar");
        Button btnEditar = new Button("Editar");
        Button btnEliminar = new Button("Eliminar");
        Button btnBuscar = new Button("Buscar");

        btnGuardar.setPrefWidth(90);
        btnEditar.setPrefWidth(90);
        btnEliminar.setPrefWidth(90);
        btnBuscar.setPrefWidth(90);

        HBox botones = new HBox(10);

        botones.getChildren().addAll(
                btnGuardar,
                btnEditar,
                btnEliminar,
                btnBuscar
        );

        formulario.add(botones,1,8);

        // ===== TABLA =====

        TableView<String> tabla = new TableView<>();

        TableColumn<String,String> colCodigo =
                new TableColumn<>("Codigo");

        TableColumn<String,String> colProducto =
                new TableColumn<>("Producto");

        TableColumn<String,String> colCategoria =
                new TableColumn<>("Categoría");

        TableColumn<String,String> colPrecio =
                new TableColumn<>("Precio");

        TableColumn<String,String> colCantidad =
                new TableColumn<>("Cantidad");

        TableColumn<String,String> colEstado =
                new TableColumn<>("Estado");

        tabla.getColumns().addAll(
                colCodigo,
                colProducto,
                colCategoria,
                colPrecio,
                colCantidad,
                colEstado
        );

        tabla.setPrefHeight(220);

        VBox parteInferior = new VBox(tabla);
        parteInferior.setPadding(new Insets(20));

        root.setBottom(parteInferior);

        // ===== ESCENA =====

        Scene scene = new Scene(root,900,650);

        primaryStage.setTitle("Sistema de Inventario");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}